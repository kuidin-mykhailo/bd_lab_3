import { Skud } from './skud';

describe('SkudInfo', () => {
  it('should create an instance', () => {
    expect(new Skud()).toBeTruthy();
  });
});
