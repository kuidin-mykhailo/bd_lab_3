import { VisitCounter } from './visit-counter';

describe('VisitCounter', () => {
  it('should create an instance', () => {
    expect(new VisitCounter()).toBeTruthy();
  });
});
