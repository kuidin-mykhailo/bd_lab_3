export class VisitCounter {
    skudId: number;
    visitsCount: number;
    visitDate: Date;
}
