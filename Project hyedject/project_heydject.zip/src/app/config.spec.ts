import { Config } from './config';

describe('Config', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Config()).toBeTruthy();
  });
});
