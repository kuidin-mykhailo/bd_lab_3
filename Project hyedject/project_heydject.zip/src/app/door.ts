export class Door {
  skudId: number;
  doorStatus: boolean;
  doorName: string;
}
