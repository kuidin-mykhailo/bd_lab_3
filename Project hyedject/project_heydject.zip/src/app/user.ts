export class User {
  id: string;
  name: string;
  surname: string;
  cardId: string;
  password: string;
  imageUrl: string;
}


//TODO Должность, группа

