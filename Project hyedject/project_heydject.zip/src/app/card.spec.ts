import { Card } from './card';

describe('Card', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Card()).toBeTruthy();
  });
});
