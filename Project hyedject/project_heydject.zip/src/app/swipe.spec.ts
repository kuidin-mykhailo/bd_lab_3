import { Swipe } from './swipe';

describe('Swipe', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new Swipe()).toBeTruthy();
  });
});
