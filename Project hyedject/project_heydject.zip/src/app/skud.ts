export class Skud {
  id: number;
  name: string;
  constructor(newId: number, newName: string) {
    this.id = newId;
    this.name = newName;
  }
}
