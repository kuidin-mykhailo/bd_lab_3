import { Door } from './door';

describe('Door', () => {
  it('should create an instance', () => {
    expect(new Door()).toBeTruthy();
  });
});
